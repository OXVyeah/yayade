# -*- coding:utf-8 -*-
from  Tkinter import *
class Application(Frame):
    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.pack()
        self.createWidgets()

    def createWidgets(self):
        self.helloLabel = Label(self, text='Hello, world!')
        self.helloLabel.pack()
        self.quitButton = Button(self, text='Quit', command=self.quit)
        self.quitButton.pack()


#app = Application()
# 设置窗口标题:
#app.master.title('Hello World')
# 主消息循环:
#app.mainloop()





# from tkinter import *
# from FIND_UPDATE import *
import collections
import re
import time

url_dict=[]
white_url_dict=collections.defaultdict(lambda: 0)
black_url_dict=collections.defaultdict(lambda: 0)

################读取本地黑白名单
f_black = open(r"E:\x小学期\汇总演示\black.txt")
f_white = open(r"E:\x小学期\汇总演示\white.txt")
def serial_url():
    for items in f_black:
        items = items.strip('\n')
        #print(items)
        black_url_dict[items]=1
    f_black.close()
    for items in f_white:
        items = items.strip('\n')
        white_url_dict[items] = 1
    f_white.close()
    return 0
serial_url()
url_dict.append(white_url_dict)
url_dict.append(black_url_dict)

#######################操作函数
def add(url):#添加函数，成功返回
    if not url_dict[v.get()][url]:
        url_dict[v.get()][url] = 1
        return 1
    else:
        return 0


def delete(url):#删除函数，成功返回1
    if url_dict[v.get()][url] == 1:
        del url_dict[v.get()][url]
        return 1
    else:
        return 0


def search(url):#检索函数
    if v.get()==1:
        if (url_dict[v.get()][url] == 1 or find_url(url) !=1 or find_url("http://"+url) !=1 ):#如果在本地或者数据库中存在
            print("检索成功")
            return 1
        else:
            print("检索失败")
            del url_dict[v.get()][url]
            return 0
    if v.get() == 0:
        if (url_dict[v.get()][url] == 1 or find_white_url(url) != 1 or  find_white_url("http://"+url) !=1):
            print("检索成功")
            return 1
        else:
            print("检索失败")
            del url_dict[v.get()][url]
            return 0

################判断url是否合法
def is_legal(url):
    if re.match(r'^(http://|https://)?((?:[A-Za-z0-9]+-[A-Za-z0-9]+|[A-Za-z0-9]+)\.)+([A-Za-z]+)[/\?\:]?.*$', url):
        return 1
    # ip:1.1.1.1 or http://1.1.1.1
    elif re.match(
            r'^(http://|https://)?((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})(\.(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[0-9]{1,2})){3})$',url):
        return 1
    else:
        return 0


###########添加部分
def show_add_page1():
    page_s = Toplevel()
    page_s.title('提示')
    page_s.geometry('400x200')
    Label(page_s, text='添加成功').pack()


def show_add_page2():
    page_e = Toplevel()
    page_e.title('错误')
    page_e.geometry('400x200')
    Label(page_e, text='添加失败，已有该URL').pack()


def is_add():#添加函数
    # if (u.get() == '' or is_legal(u.get())==0):#输入为空或不合法
        show_check_page()
        #return 0
    if v.get() == 2:#未选择黑白名单平面
        show_info_page()

    add_flag = add(text_blank.get())
    if add_flag == 1:#添加成功，显示添加成功页面
        show_add_page1()
        u.set("")
    else:#添加失败，显示添加失败页面
        show_add_page2()
        u.set("")


###########删除部分
def show_del_page1():
    page_s = Toplevel()
    page_s.title('提示')
    page_s.geometry('400x200')
    Label(page_s, text='删除成功').pack()


def show_del_page2():
    page_e = Toplevel()
    page_e.title('错误')
    page_e.geometry('400x200')
    Label(page_e, text='删除失败，找不到该URL').pack()


def is_delete():#删除函数
    if (u.get() == '' or is_legal(u.get())==0):#如果url合法或不为空
        show_check_page()
        return 0
    if v.get() == 2:
        show_info_page()
        return 0
    del_flag = delete(text_blank.get())
    if del_flag == 1:
        show_del_page1()
        u.set("")
    else:
        show_del_page2()
        u.set("")


###########检索
def show_search_page1():#成功页面
    page_s = Toplevel()
    page_s.title('提示')
    page_s.geometry('400x200')
    Label(page_s, text='检索成功，URL在该名单内').pack()


def show_search_page2():#失败页面
    page_e = Toplevel()
    page_e.title('错误')
    page_e.geometry('400x200')
    Label(page_e, text='检索失败，找不到该URL').pack()


def is_search():#搜索函数
    if (u.get() == '' or is_legal(u.get())==0):
        show_check_page()
        return 0
    if v.get() == 2:
        show_info_page()
        return 0
    if search(text_blank.get()) == 1:
        show_search_page1()
        u.set("")
    else:
        show_search_page2()
        u.set("")


##############查看本地文件
def show():
    if v.get() == 2:
        show_info_page()
        return 0
    page = Toplevel()
    page.title('查看')
    page.geometry('200x250')
    if v.get() == 1:
        Label(page, text='黑名单').pack()
    else:
        Label(page, text='白名单').pack()
    url_list = Listbox(page)
    for item in url_dict[v.get()]:
        url_list.insert(0, item)
    url_list.pack()


###############提示页面
def show_info_page():
    page = Toplevel()
    page.title('提示')
    page.geometry('200x200')
    Label(page, text='请选择黑白名单').pack()


def show_check_page():
    page = Toplevel()
    page.title('提示')
    page.geometry('200x200')
    Label(page, text='输入URL不合法').pack()


###############主页面
root = Tk()
root.title("网页钓鱼URL过滤系统")
root.geometry('500x300')

display = Label(root, text="欢迎使用").pack()

############选择
v = IntVar()
v.set(2)
select1 = Radiobutton(root, text="白名单", variable=v, value=0).pack(side=TOP)
select2 = Radiobutton(root, text="黑名单", variable=v, value=1).pack(side=TOP)

############文本框
u = StringVar()
frame = Frame(root).pack(padx=8, pady=8, ipadx=4)
lab = Label(frame, text="请输入URL:").pack()
text_blank = Entry(frame, textvariable=u, width=40)
text_blank.pack()

############按钮
button1 = Button(root, text="添加", command=is_add, width=20).pack(side=TOP)
button2 = Button(root, text="删除", command=is_delete, width=20).pack(side=TOP)
button3 = Button(root, text="检索", command=is_search, width=20).pack(side=TOP)
button4 = Button(root, text="查看", command=show, width=20).pack(side=TOP)

root.mainloop()

########保存数据到本地文件
#f_black = open(r"E:\x小学期\汇总演示\black.txt",'w')
#f_white = open(r"E:\x小学期\汇总演示\white.txt",'w')
# for items in url_dict[0]:
#     f_white.write(items+'\n')
# f_white.close()
# for items in url_dict[1]:
#     f_black.write(items+'\n')
# f_black.close()